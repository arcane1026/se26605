<!doctype html>

<html lang="en">
<head>
	<meta charset="utf-8">
	
	<title>corporations manager</title>
	<h1>Corporation App</h1>
	<meta name ="description" content="corporations manager">
	<meta name = "Angelo LaGreca">
	</head>
	<body>
	