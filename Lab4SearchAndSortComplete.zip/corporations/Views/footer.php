<div id = "footer">
Copywrite &copy; <?php echo date('Y'); ?>, Angelo LaGreca and NEtech. All rights reserved.
</div>
</body>
</html>